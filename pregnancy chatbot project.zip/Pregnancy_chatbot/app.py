from flask import Flask, render_template, request, jsonify
import requests
import json
import os

app = Flask(__name__)

# Load Gemini API key from environment variable
GEMINI_API_KEY = os.getenv("GEMINI_API_KEY")
if not GEMINI_API_KEY:
    raise EnvironmentError("GEMINI_API_KEY environment variable not set.")

GEMINI_ENDPOINT = f"https://generativelanguage.googleapis.com/v1/models/gemini:generateContent?key={GEMINI_API_KEY}"

def get_ai_response(week):
    prompt = f"You are a pregnancy assistant. Provide helpful advice for a woman who is {week} weeks pregnant."

    headers = {
        "Content-Type": "application/json"
    }

    data = {
        "contents": [
            {
                "role": "user",
                "parts": [
                    {
                        "text": prompt
                    }
                ]
            }
        ]
    }

    try:
        response = requests.post(GEMINI_ENDPOINT, headers=headers, data=json.dumps(data), timeout=10)
        result = response.json()

        # Debugging: print full response (optional)
        # print("Gemini raw response:", json.dumps(result, indent=2))

        if response.status_code != 200:
            error_msg = result.get("error", {}).get("message", "Unknown error from Gemini API")
            return f"Gemini API Error: {error_msg}"

        candidates = result.get("candidates", [])
        if candidates:
            parts = candidates[0].get("content", {}).get("parts", [])
            if parts:
                return parts[0].get("text", "No response content found.")

        return "Unexpected response structure from Gemini API."

    except Exception as e:
        return f"An error occurred while calling Gemini API: {str(e)}"

@app.route("/")
def index():
    return render_template("index.html")

@app.route("/chat", methods=["POST"])
def chat():
    week = request.form.get("week", "").strip()
    if not week.isdigit() or not (1 <= int(week) <= 40):
        return jsonify({"response": "Please enter a valid pregnancy week between 1 and 40."})

    response = get_ai_response(week)
    return jsonify({"response": response})

if __name__ == "__main__":
    app.run(debug=True)
